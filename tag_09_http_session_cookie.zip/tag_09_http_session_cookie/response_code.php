<?php

http_response_code(500);
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <p>Hi, die Seite gint es nicht!</p>
    </body>
</html>