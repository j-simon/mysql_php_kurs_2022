<?php


$username = "";

if ($_POST) {
    session_start();
    $username = $_POST['username'];

    //var_dump($_SESSION);

    $_SESSION['username'] = $username;
    //var_dump($_SESSION);
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Session Test</title>
</head>

<body>
    <a href="geheimnisse.php">Geheimnisse</a>
    <h1>Login</h1>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
        Username<input type="text" name="username">
        <input type="submit">

    </form>

    <p>Hallo <?php echo $username; ?></p>

</body>

</html>