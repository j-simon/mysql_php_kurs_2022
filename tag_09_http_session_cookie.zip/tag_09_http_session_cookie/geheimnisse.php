<?php
    session_start();
   
    if (isset( $_SESSION['username']))
      $username = $_SESSION['username']; // key ist nicht immer da
    else
      $username ="";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Geheimnisse</title>
    </head>
    <body>
        <p>Ein Geheimnis für <?php echo $username;?></p>
        <a href="loeschen.php">Session beenden</a>
    </body>
</html>