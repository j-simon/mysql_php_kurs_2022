<?php
phpinfo();
 session_start();
 $_SESSION['meldung'] = 'Speicherung erfolgreich';