<?php

echo "deutsch";
