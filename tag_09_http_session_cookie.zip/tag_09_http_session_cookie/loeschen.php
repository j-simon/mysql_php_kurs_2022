<?php
    session_start();
    //var_dump($_SESSION);

    unset($_SESSION['username']);
    //unset($_SESSION);
    //setcookie("PHP_SESSID"); // loesche 

    