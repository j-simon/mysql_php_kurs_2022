<?php
var_dump($_SERVER);
$accept_language = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
echo $accept_language;

// de-DE,de;q=0.5 
// en-US,en;q=0.9,de-DE;q=0.8,de;q=0.7
$sprache = explode(";",$accept_language,2);


if ($sprache[0] == "de-DE,de") {
    header("Location: deutsch.php");
} elseif($sprache[0] == "en-US,en") {
    header("Location: englisch.php");
}

?>
<!DOCTYPE html>
<html>

<head>
    <link href="fehler.css" rel="stylesheet">
    <meta charset="utf-8">
    <script src="fehler.js"></script>
    <title>Testseite</title>
</head>

<body>
    <h1>üBERSCHRIFT</h1>
    <img src="fehler.png">
    <img src="it-berufe-mit-zukunft.webp">
    <?php if ($sprache[0] == "de-DE,de") { ?>
        <p>Herzlich Willkommen</p>
    <?php } else { ?>
        <p>Welcome</p>
    <?php } ?>
</body>

</html>
