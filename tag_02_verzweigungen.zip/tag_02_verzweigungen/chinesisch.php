<?php
$vorname="ww";

$我们不是美国人 = "Jens";

echo $我们不是美国人;