<?php


//echo intval( "Jens");

// === Identitätsoperator 
// 1. Datentyp-Vergleich 
// 2. == nur wenn 1. ja
//echo 1 === 1; // true
if (1 === "1") // false
{
    echo "true";
} else {
    echo "false";
}
// == Gleichheitsoperator
// wert == wert
//echo 1 == 1; // true
if (
    1 == "1" &&
    2 == 4
) {
    echo "true";
} else {
    echo "false";
}

if(true) {
    echo "hallo";
}

if(true):
    echo "hallo";
endif;

// 1. Ersatz ternärer Operator / Bedingungsoperator
 $name = 11 < 22 ? "Jens" : "Tim";

if( 11 < 22)
{
    $name=  "Jens";
} else {
    $name=  "Tim";
}



 if( $geburtsjahr < 22)
{
    $name=  "Jens";
} elseif ( $geburtsjahr == 21) {
    $name=  "Tim";
} elseif ( $geburtsjahr == 23) {
    $name=  "Kim";
} elseif ( $geburtsjahr == 27){
    $name=  "Tina";
} 
echo $name;


switch($geburtsjahr){
    
    case 22:
            $name=  "Tim";
             break;
    
    case 24:
            $name=  "Kim";
            break;
}