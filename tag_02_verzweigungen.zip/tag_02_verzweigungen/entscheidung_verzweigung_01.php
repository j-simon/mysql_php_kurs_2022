<?php

//  ()
if (3 == 4) 

    // true ja
    echo "true/ja";
else {

    // false nein
    echo "false/nein";
    echo "2. Statement";
}

// Varianten ja/nein blöcke
// der false Block ist optional(kann weggelassen werden)

if (3 == 4) {

    // true ja
    echo "true/ja";
}



// wenn ein Befehl/statement in einem Block ist ,
// kann die geschweifte Klammerung weggelassen werden
if (3 == 4)
    echo "true/ja";
