<?php
//var_dump($_GET);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <form action="">
            Geburtsjahr<input type="text" name="geburtsjahr">
        <input type="submit">
        </form> 
    </body>
</html>
<?php

$geburtsjahr = $_GET['geburtsjahr'];
echo $geburtsjahr." ";
echo gettype($geburtsjahr);

$geburtstag = (int) $geburtstag;
if (2000 >= $geburtsjahr ) {
    echo "du bist älter als 21!";
} else {
    echo "du bist noch nicht 21!";
}
/*
if ("11"  < "elf")  // true "1" < "e" -> true
    echo "true";
else 
    echo "false";

*/
$zahl = -111; // number
$text = "2006"; // string // input-textfeld eines formular

if ( $zahl < $text)  // false 
    echo "true";
else 
    echo "false";
