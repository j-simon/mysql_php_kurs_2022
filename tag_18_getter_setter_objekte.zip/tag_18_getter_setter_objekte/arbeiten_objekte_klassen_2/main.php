<?php

require_once "Person.php";
require_once "Stadt.php";

$hamburg = new Stadt();
$hamburg->setName("Hamburg");
$hamburg->setPostleitzahlen([22147,22049,]);
$hamburg->setEinwohnerzahl(1800001);

$koeln = new Stadt();
$koeln->setName("Köln");
$koeln->setPostleitzahlen([50667,50668,]);
$koeln->setEinwohnerzahl(1003000);

$jens = new Person();
$jens->setVorname("Jens");
$jens->setNachname("Simon");
$jens->setStadt($koeln);
$jens->zeigeStadtAn();

