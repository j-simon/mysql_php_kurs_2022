<?php

class Person {

    // attributes
    protected $vorname = "";
    protected $nachname = "";

    // methods
    public function zeigePersonenAn(){
         
        echo $this->getVorname()." - ".$this->getNachname();
        echo "<br>";
     }
     




    /**
     * Get the value of vorname
     */ 
    public function getVorname()
    {
        return strtolower($this->vorname);
    }

    /**
     * Set the value of vorname
     *
     * @return  self
     */ 
    public function setVorname($vorname)
    {
        $this->vorname = $vorname;

        return $this;
    }

    /**
     * Get the value of nachname
     */ 
    public function getNachname()
    {
        return strtolower($this->nachname);
    }

    /**
     * Set the value of nachname
     *
     * @return  self
     */ 
    public function setNachname($nachname)
    {
        $this->nachname = $nachname;

        return $this;
    }
}