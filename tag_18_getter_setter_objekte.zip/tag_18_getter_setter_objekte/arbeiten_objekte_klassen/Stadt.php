<?php

class Stadt {

    // attribute
    protected $name = "";
    protected $postleitzahlen = [];
    protected $einwohnerzahl = 0;
      

    /**
     * Get the value of name
     */ 
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set the value of name
     *
     * @return  self
     */ 
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get the value of postleitzahlen
     */ 
    public function getPostleitzahlen()
    {
        return $this->postleitzahlen;
    }

    /**
     * Set the value of postleitzahlen
     *
     * @return  self
     */ 
    public function setPostleitzahlen($postleitzahlen)
    {
        $this->postleitzahlen = $postleitzahlen;

        return $this;
    }

    /**
     * Get the value of einwohnerzahl
     */ 
    public function getEinwohnerzahl()
    {
        return $this->einwohnerzahl;
    }

    /**
     * Set the value of einwohnerzahl
     *
     * @return  self
     */ 
    public function setEinwohnerzahl($einwohnerzahl)
    {
        $this->einwohnerzahl = $einwohnerzahl;

        return $this;
    }
}