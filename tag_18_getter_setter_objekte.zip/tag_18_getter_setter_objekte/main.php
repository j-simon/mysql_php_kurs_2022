<?php
error_reporting(0);

class Schuh {

// Attribute
public $groesse;// = '40';
public $art ;//= 'Sportschuh';
public $material = 'Plastik';
public $preis = '100.0';


/**
 * Get the value of groesse
 */ 
public function getGroesse()
{
return $this->groesse;
}

/**
 * Set the value of groesse
 *
 * @return  self
 */ 
public function setGroesse($groesse)
{
$this->groesse = $groesse;

return $this;
}

/**
 * Get the value of preis
 */ 
public function getPreis()
{
return $this->preis;
}

/**
 * Set the value of preis
 *
 * @return  self
 */ 
public function setPreis($preis)
{
$this->preis = $preis;

return $this;
}
}




// aussen
$jensSchuhLinks = new Schuh();

var_dump($jensSchuhLinks);

$zahl;
var_dump($zahl);

























