<?php

class Haustier {

}