<?php

require_once "Person.php";

$person1 = new Person();

$person1->setVorname("Jens");
$person1->setNachname("Simon");
//var_dump($person1);

$person2 = new Person();
$person2->setVorname("Henry");
$person2->setNachname("Frank");

// Datensammlung Array
$gfnMysqlPHPKurs=[
   $person1, $person2
];
//var_dump($gfnMysqlPHPKurs);
foreach($gfnMysqlPHPKurs as $person)
  $person->zeigePersonenAn();

