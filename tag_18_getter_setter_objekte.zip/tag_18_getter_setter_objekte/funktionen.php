<?php

// Umleitung zu einer $url
function redirect($url="index.php"){
    
    // 1. schreiben Daten irgendwie haben

    // 2. umleitung
    header("Location: " . $url);
    exit();
}