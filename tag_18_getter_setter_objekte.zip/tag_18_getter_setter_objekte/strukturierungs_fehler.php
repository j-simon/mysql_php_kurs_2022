<p class='inhalt'>
<p class="inhalt">

<?php
require_once "funktionen.php";


redirect("index.php");
header();
exit();
// nicht chick
echo "<p class='inhalt'>" . $n['inhalt'] . "</p>";
echo '<p class="inhalt">' . $n['inhalt'] . "</p>";
?>
<p class="inhalt"><?=  $n['inhalt'] ?></p>
<?php 
header();
exit();
?>

