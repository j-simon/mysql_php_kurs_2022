<?php
$titel = "Dies ist eine tolle Website";
$content = "Guten Tag ....";

$vornamen = ["Jens", "Tim", "Olaf"];; ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title><?php echo $titel; ?></title>
</head>

<body>
    <p><?php echo $content; ?></p>
    <p><?= $content ?></p>
    <h2>Liste der Namen</h2>
    <ul>
        <?php foreach ($vornamen as $vorname) {      ?>
            <?php if ($vorname == "Jens") { ?>
                <li><?= $vorname ?></li>
            <?php } ?>
        <?php } ?>
    </ul>
    <ul>
        <?php foreach ($vornamen as $vorname) :      ?>
            <?php if ($vorname == "Jens") : ?>
                <li><?= $vorname ?></li>
            <?php endif ?>
        <?php endforeach ?>
    </ul>
</body>

</html>