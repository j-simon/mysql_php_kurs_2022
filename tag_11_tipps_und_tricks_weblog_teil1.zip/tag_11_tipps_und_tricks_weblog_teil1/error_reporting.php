<?php

// error_reporting -> Server Einstellung des PHP-Modul php.ini
// ERROR, WARNING, NOTICE
error_reporting(0); // für den produktiven Betrieb !

const A = 1;
const A = 2;

