<?php
require "inc/konfiguration.inc.php";
require "inc/funktionen.inc.php";
session_start();



$eintraege = []; // 3 Eintraege beim Start nach Vorgabe

$eintraege[0]['titel'] = "Überschrift1";
$eintraege[0]['inhalt'] = "Mit Blindheit per Definition geschlagen, dennoch nicht unsichtbar,
präsentiere ich mich als unbeachtetes und ungeliebtes Stiefkind
zeitgenössischer Literatur. Meine Bestimmung liegt - wie ich selbst -
in engen Grenzen und ist rein platzhalterischer Natur.

Kann ein missbrauchtes Wortgefüge eigentlich noch Schlimmeres
erleiden, als als Blindtext erdacht und vor der Öffentlichkeit
versteckt zu werden?";


$eintraege[1]['titel'] = "Überschrift2";
$eintraege[1]['inhalt'] = <<<EOT
Mit Blindheit "per" Definition geschlagen, dennoch nicht unsichtbar,
präsentiere ich 'mich' als unbeachtetes und ungeliebtes Stiefkind
zeitgenössischer Literatur. Meine Bestimmung liegt - wie ich selbst -
in engen Grenzen und ist rein platzhalterischer Natur.

Kann ein missbrauchtes Wortgefüge eigentlich noch Schlimmeres
erleiden, als als Blindtext erdacht und vor der Öffentlichkeit
versteckt zu werden?
EOT;


$eintraege[2]['titel'] = "Überschrift3";
$eintraege[2]['inhalt'] = "Inhalt3";

//var_dump($eintraege);

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Startseite - Weblog</title>
    <link href="css/stylesheet.css" rel="stylesheet">
</head>

<body>

    <div id="gesamt">

        <header id="kopf">
            <h1>Mein Weblog</h1>
        </header>


        <section id="content">
            <?php foreach ($eintraege as $e) : ?>
                <?php include "inc/eintrag.tpl.php";    ?>
            <?php endforeach ?>
        </section>

        <aside id="menu">
            <?php 
            if(istEingeloggt()) {  
                include "inc/hauptmenu.tpl.php";  
            } else {
                include "inc/loginformular.tpl.php";  
            }
            ?>
        </aside>
    </div>
</body>

</html>