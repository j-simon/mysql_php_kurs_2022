<?php

 // login / einlogen
 // session_start();
 // $_SESSION

 function istEingeloggt(){ 
    return  isset($_SESSION['eingeloggt']);
 }

 function loggeEin($username) {
    $_SESSION['eingeloggt'] = $username;
 }

 function loggeAus() {
    //unset($_SESSION['eingeloggt']);
    session_destroy();
 }

 function holeEingeloggterBenutzer(){
    return  $_SESSION['eingeloggt'];
 }