<article class="eintrag">
    <header class="eintrag_oben">
        <h1><?= $e['titel'] ?></h1>
    </header>

    <p>
        <?= $e['inhalt'] ?>
    </p>

    <footer class="eintrag_unten">
        <span>
            geschrieben von
              am
          
        </span>
    </footer>
</article>