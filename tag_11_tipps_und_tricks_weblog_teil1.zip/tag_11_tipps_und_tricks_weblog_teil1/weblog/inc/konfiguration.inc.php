<?php
const PFAD_EINTRAEGE = "eintraege.txt";
const BENUTZER_DATEN =  [
    'inewton' => [
        'vorname' => 'Isaac',
        'nachname' => 'Newton',
        'passwort' => 'apfel',
    ],
    'jsartre' => [
        'vorname' => 'Jean-Paul',
        'nachname' => 'Sartre',
        'passwort' => 'vernunft',
    ],
    'ghegel' => [
        'vorname' => 'Georg Wilhelm Friedrich',
        'nachname' => 'Hegel',
        'passwort' => 'logisch',
    ],
];