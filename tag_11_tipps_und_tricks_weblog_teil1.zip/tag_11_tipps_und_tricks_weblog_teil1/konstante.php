<?php
echo FILE_APPEND;

// Variable
$vorname = "Jens"; // 1. Wertzuweisung (Initialisierung)
$vorname = "Tim";  // 2. Wertzuweisung

echo $vorname;

echo "<br>";
// Konstante
// Schreibweise a)
define("NACHNAME","Simon");
//define("NACHNAME","Koch");
echo NACHNAME;

echo "<br>";
// Schreibweise b)
const NACH_NAME = "Koch";
echo NACH_NAME;
// define("FILE_APPEND",23);