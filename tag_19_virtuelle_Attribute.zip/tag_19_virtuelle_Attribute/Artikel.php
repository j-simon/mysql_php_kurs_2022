<?php
class Artikel{

protected $titel;
protected $nettoPreis;



// virtuellen Getter
public function getBruttoPreis()
{
return number_format($this->nettoPreis * 1.19,2);
}
/**
 * Get the value of titel
 */ 
public function getTitel()
{
return $this->titel;
}

/**
 * Set the value of titel
 *
 * @return  self
 */ 
public function setTitel($titel)
{
$this->titel = $titel;

return $this;
}

/**
 * Get the value of nettoPreis
 */ 
public function getNettoPreis()
{
return $this->nettoPreis;
}

/**
 * Set the value of nettoPreis
 *
 * @return  self
 */ 
public function setNettoPreis($nettoPreis)
{
$this->nettoPreis = $nettoPreis;

return $this;
}
}