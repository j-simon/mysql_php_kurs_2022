<?php

class Person{

// attributes
protected $vorname;
protected $nachname;

// virtual attríbute
// proteted $name;

// methods

public function getName()
{
    return $this->vorname." ".$this->nachname;
}

public function setName($name)
{
    // untersuche den $name auf die gewünschte Struktur
    // "vorname nachname"
    $this->vorname = explode(" ",$name)[0] ?? "";
    $this->nachname = explode(" ",$name)[1]?? "";
    return $this;
}
// Getter / Setter


/**
 * Get the value of vorname
 */ 
public function getVorname()
{
    return $this->vorname;
}

/**
 * Set the value of vorname
 *
 * @return  self
 */ 
public function setVorname($vorname)
{
    $this->vorname = $vorname;

    return $this;
}

/**
 * Get the value of nachname
 */ 
public function getNachname()
{
    return $this->nachname;
}

/**
 * Set the value of nachname
 *
 * @return  self
 */ 
public function setNachname($nachname)
{
    $this->nachname = $nachname;

    return $this;
}
}
