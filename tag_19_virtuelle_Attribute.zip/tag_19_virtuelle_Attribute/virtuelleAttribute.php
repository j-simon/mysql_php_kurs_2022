<?php
require_once "Person.php";
require_once "Artikel.php";
// Attribut?

// Variable, Eigenschaft, attribute, property, field, Spaltenüberschaft(SQL-Tabelle)

// virtuell ?
// nicht real

// Objekt bilden als Instanz der Klasse Person
$jens = new Person();

/*$jens->setVorname("Jens");
echo $jens->getVorname();

$jens->setNachname("Simon");
echo $jens->getNachname();
*/
$jens->setName("Jens Simon");
//echo $jens->getName();

$handy = new Artikel();
$handy2 = new Artikel();

$handy->setTitel("Phone");
$handy->setNettoPreis(600.5);

$handy2->setTitel("Phone2");
$handy2->setNettoPreis(800.5);
?>Handy: 
<?= $handy->getBruttoPreis();?>
 BruttoPreis<br>
 Handy: 
<?= $handy2->getBruttoPreis();?>
 BruttoPreis<br><hr>
Gesamtpreis: <?= $handy->getBruttoPreis() + $handy2->getBruttoPreis() ?> € 
<? $handy->getBruttoPreis(); ?>

