<?php

// Parameter von Typ string
function gibTextAus(string $message){

    echo gettype($message);
    echo " - ";
    var_dump($message);
    echo "<br>";

}
function gibWasAus(Test1 $message){

    echo gettype($message);
    echo " - ";
    echo get_class($message);
    echo " - ";
    var_dump($message);
    echo "<br>";

    echo $message->a;

}

/*gibTextAus("Guten Morgen");

gibTextAus("Guten Abend");

gibTextAus(10);*/


class Test1 {
 public $a=10;
 public $b=20;
}
$obj1 = new Test1();

gibWasAus($obj1); // nur mir einem object von Typ Test1 ist diese Funktions aufrufbar


class Test2 {
    public $c="asad";
    public $d="dsfds";
   }
$obj2 = new Test2();
//gibWasAus($obj2); // dieser Aufruf der Funktion ist nicht erlaubt