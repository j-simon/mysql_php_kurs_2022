<?php
 declare(strict_types=1);
 phpinfo();



function sum(int $a,int $b) : int
{
    $c= $a + $b ;
    return $c; // int
}

var_dump(sum(1, 2));
//var_dump(sum(false, true));
//var_dump(sum(1.5, 2.5));
//var_dump(sum(NULL, NULL));