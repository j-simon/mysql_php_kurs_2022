<?php
// Konzept der Klasse 

class A{
    // Funktion/Methode in einer Klasse 
    function tueEtwas()
    {
        echo "A - tuewas";
    }

}


class B {
    function tueEtwas() // redifinition error
    {
        echo "B - tuewas";
    }
}

// 2 verscheidenen Funktionen mit dem selben Namen
// können jetzt benutzt werden
$klasse1 = new A();
$klasse1->tueEtwas(); 

echo "<br>";

$klasse2 = new B();
$klasse2->tueEtwas();

