<?php
 // Datenbank-Client selbst programmiert


 // MAMP
 $hostname = "localhost";// "mysql31.1blu.de" // ip-adresse oder über einen domain-name
 $port = 3308; // 3306
 $dbname = "filme";
 $username = "root";
 $password = "root"; 

 // XAMPP
 /*
 $hostname = "localhost";
 $dbname = "mysql";
 $username = "root";
 $password = "";*/

$dsn = 'mysql:host='.$hostname.';port='.$port.';dbname='.$dbname; // data source name // datenquellen name -> welchen servertyp und adresse
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_BOTH
];
 
// Der Erzeugung eines PDO Objektes
// 1.Verbindungsaufbau mit Server
$db = new PDO($dsn,$username, $password,$options ) ; // Klasse dient der Einstellung der Server

// 2. SQL-Befehl formulieren und zum Server schicken
$ergebnis = $db->query("SELECT * FROM darsteller;");
//var_dump($ergebnis);

/*
// 3. Ergebnis vom Server abholen // 2dim Array
$daten = $ergebnis->fetchAll();
//var_dump($daten);

// 4. Verarbeitung
foreach($daten as $zeile) {
    echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";
}*/

// 3. Ergebnis vom Server abholen // 1dim Array
$zeile = $ergebnis->fetch();
//var_dump($daten);

// 4. Verarbeitung
echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";

// 3. Ergebnis vom Server abholen // 1dim Array
$zeile = $ergebnis->fetch();
//var_dump($daten);

// 4. Verarbeitung
echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";


// 3. Ergebnis vom Server abholen // 1dim Array
$zeile = $ergebnis->fetch();
//var_dump($daten);

// 4. Verarbeitung
echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";

// 3. Ergebnis vom Server abholen // 1dim Array
$zeile = $ergebnis->fetch();
//var_dump($daten);

// 4. Verarbeitung
echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";


// 3. Ergebnis vom Server abholen // 1dim Array
$zeile = $ergebnis->fetch();
//var_dump($daten);

// 4. Verarbeitung
echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";

// 3. Ergebnis vom Server abholen // 1dim Array
$zeile = $ergebnis->fetch();
//var_dump($daten);

// 4. Verarbeitung
echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";

// 3. Ergebnis vom Server abholen // 1dim Array
$zeile = $ergebnis->fetch();
//var_dump($daten);

// 4. Verarbeitung
echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";

// 3. Ergebnis vom Server abholen // 1dim Array
$zeile = $ergebnis->fetch();
//var_dump($daten);

// 4. Verarbeitung
echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";

// 3. Ergebnis vom Server abholen // 1dim Array
$zeile = $ergebnis->fetch();
//var_dump($daten);

// 4. Verarbeitung
echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";

// 3. Ergebnis vom Server abholen // 1dim Array
$zeile = $ergebnis->fetch();
//var_dump($daten);

// 4. Verarbeitung
echo $zeile['id']." ".mb_substr($zeile['vorname'],0,3)." ".$zeile['nachname']." ".ucfirst($zeile['geschlecht'])."<br>";
