<?php

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <p><?php
//phpinfo();

/* locale auf Holländisch setzen */
setlocale(LC_ALL, 'Ar_Ar');

/* Ausgabe: vrijdag 22 december 1978 */
echo strftime("%A %d %B %Y", mktime(0, 0, 0, 12, 22, 1978));

$zahl = time(); // in Sekunden seit 01.01.1970 00:00:00 GMT 
echo $zahl;
echo "<br>";

$text = strftime('%H:%M:%S %d.%B.%Y'); // Systemzeit
echo $text;
echo "<br>";

$termin = mktime(13,0,0,7,5,205);
echo $termin;
echo "<br>";
$text = strftime(' %d.%B.%Y %H:%M:%S' , $termin); // selbstdefiniert
echo $text;
?></p>
    </body>
</html>