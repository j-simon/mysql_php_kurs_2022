<?php

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <p><?php
        $inhalt = $_GET['inhalt'];
        
       // var_dump($inhalt);
       
       $geschuetzterInhalt= htmlspecialchars($inhalt);//,ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML401,null,true);
       
       echo $geschuetzterInhalt;
       //var_dump($geschuetzterInhalt);
        ?></p>
    </body>
</html><?php

