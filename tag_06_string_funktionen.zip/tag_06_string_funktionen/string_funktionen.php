<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        <p><?php 
        $text = strtolower("JeNS");
        //echo $text;

        $text = strtoupper("JeNS");
        //echo $text;

        $text=ucfirst("äns");
        //echo $text;

        $text=lcfirst("Jens");
        echo $text;


        ?></p>
    </body>
</html>