<?php

// 
// trim(string $string, string $characters = " \n\r\t\v\x00"): string
// 2 Parameter 
// string $string
// string $characters = " \n\r\t\v\x00"): string // default Parameter

// 
// Rückgabewerte ¶
// Der gekürzte String.

$text="        Hans Werner              ";
$auffangvariable = trim($text);
//echo">";
//echo $auffangvariable;
//echo"<";
//var_dump($auffangvariable);

$text="        Hans Werner              ";
$auffangvariable = trim($text," \n\r\t\v\x00Ha");
//echo">";
//echo $auffangvariable;
//echo"<";
//var_dump($auffangvariable);

// Anfangsfall
$text="        Hans Werner              ";
echo trim($text);

$vorname = trim($_GET['vorname']);

echo "<b>".$vorname."</b>";