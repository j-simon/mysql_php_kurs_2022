<?php
$tag=5;
$monat=7;
$jahr=2022;

$datum = [$tag,$monat,$jahr];


$datei = "daten/speichern.txt";

$anzahl = file_put_contents($datei,$datum,FILE_APPEND);
echo $anzahl;


