<?php
$datei = "daten/speichern.txt";

$termin_s = file_get_contents($datei);

$termin = unserialize($termin_s);

echo $termin[0]."<br>".$termin[1];