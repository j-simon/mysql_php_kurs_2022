<?php

$datei = "/daten/speichern.txt";

if (file_exists($datei) ) {
    $ergebnis = file_get_contents($datei);

    echo nl2br($ergebnis);

    var_dump( pathinfo($datei));
}
