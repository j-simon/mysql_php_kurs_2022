<?php

$datei = "daten/speichern.txt";

if (file_exists($datei) ) {
    $ergebnis = file_get_contents($datei);

    echo $ergebnis."<br>";
    $tag =substr($ergebnis,0,2);
    echo $tag;
  

}
