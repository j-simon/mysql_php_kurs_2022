<?php
$tag = 5;
$monat = 7;
$jahr = 2022;

$datum =  [
    'eins' => $tag,
    'zwei' => $monat,
    'drei' => $jahr
];

$datum_serialized = serialize($datum);

$datei = "daten/speichern.txt";

$anzahl = file_put_contents($datei, $datum_serialized, FILE_APPEND);
echo $anzahl;
