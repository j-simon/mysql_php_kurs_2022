<?php
$text="Hallo!"."\n";

$datei = "/daten/speichern.txt";

$anzahl = file_put_contents($datei,$text,FILE_APPEND);
echo $anzahl;


$text="Neuer Text"."\n";

// überschreiben der Daten
$anzahl = file_put_contents($datei,$text,FILE_APPEND);
echo $anzahl;