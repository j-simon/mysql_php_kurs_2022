<?php

$datei = "daten/speichern.txt";

$subject="Unterricht PHP - Persistente Daten";
$datum="06.07.2022";

$kurstermin=[$subject,$datum];

$kt_s= serialize($kurstermin);
$anzahl = file_put_contents($datei,$kt_s);
echo $anzahl;




// aktualisieren des vorhandenen kurstermins
// Datum vom 6.7 auf 7.7 ändern

// 1. auslesen des bereits vorhandenen
$termin_s = file_get_contents($datei);
$termin = unserialize($termin_s);

// 2. datum suchen + 3. datum aender
$termin[1] = "07.07.2020";

// 4. datensatz/array zurückschreiben
$kt_s= serialize($termin);
$anzahl = file_put_contents($datei,$kt_s);
echo $anzahl;