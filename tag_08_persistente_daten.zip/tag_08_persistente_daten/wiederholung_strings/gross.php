<?php

    $userTextGross  = "";
    
    if ($_POST) {
        echo "ich bin ein POST-Request";
        //echo $_POST['usertext'];

        $userTextGross = mb_strtoupper($_POST['usertext']);

    } else
     echo "ich bin ein GET-Request";
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Gross</title>
</head>

<body>
    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">

        Text:<input type="text" name="usertext">
        <input type="submit">
    </form>
    <p><?php echo $userTextGross; ?></p>
</body>

</html>