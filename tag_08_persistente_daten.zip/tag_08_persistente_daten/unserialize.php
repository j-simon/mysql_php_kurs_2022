<?php

$datei = "daten/speichern.txt";

if (file_exists($datei) ) {
    $ergebnis = file_get_contents($datei);

    //echo $ergebnis;
    
    $ergebnis = unserialize($ergebnis);
    var_dump( $ergebnis);

}
