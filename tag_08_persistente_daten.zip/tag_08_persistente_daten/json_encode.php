<?php
$tag = 5;
$monat = 7;
$jahr = 2022;

$datum =  [
    'eins' => $tag,
    'zwei' => $monat,
    'drei' => $jahr
];

$datum_json_encodedd = @json_encode($datum);

$datei = "daten/speichern.txt";

$anzahl = @file_put_contents($datei, $datum_json_encodedd, FILE_APPEND);
echo $anzahl;
