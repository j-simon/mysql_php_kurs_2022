<?php

$daten = [ 
    'jens','anton', 'Tim','Anke',
];

usort($daten,function($a,$b){
   
});

var_dump($daten);

$daten = [ 
    'd','C', 'a','b',
];

// 1. Variante
usort($daten,function($wert1,$wert2){
    echo $wert1;
    echo " ";
    echo $wert2;
    echo "<br>";

    /*if($wert1 < $wert2)
        return -1;
    if($wert1 == $wert2)
        return 0;
    if($wert1 > $wert2)   
        return 1; */

    /*if($wert1 < $wert2)
        return -1;
    esleif($wert1 == $wert2)
        return 0;
    esle
        return 1; */
        
    return strtoupper($wert1) <=> strtoupper($wert2); // Spaceship-Operator
   
});

var_dump($daten);

// 2.Variante
function userFunction($wert1,$wert2){
  
        
    return $wert1 <=> $wert2; // Spaceship-Operator
   
}

usort($daten,"userFunction");

//3.Variante
usort($daten,  fn($wert1,$wert2) => $wert1 <=> $wert2);
