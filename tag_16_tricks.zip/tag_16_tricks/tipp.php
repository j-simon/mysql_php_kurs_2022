<?php

function holeDaten() {

    return [1,2,3]; // array return 
}

function holeDatenSingle() {

    return 3; // integer return 
}

// klassisch
$daten = holeDaten();
var_dump($daten);
echo $daten[2];

// abkürzung
echo holeDaten()[2]; // Dereferenzierung

$wert = holeDatenSingle();
echo $wert;
// abkürzung
echo holeDatenSingle();