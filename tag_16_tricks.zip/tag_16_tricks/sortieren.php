<?php

// Sortieren

// sort , order 

// Array


$daten = [ 
            4.5,3,10.1,8
];

// Sortierung
// 3, 4, 8 kleinste zum grössten
// 4,3,8
// 8, 4, 3 grösste zum kleinste

sort($daten,SORT_REGULAR); // ascending aufsteigend

var_dump($daten);

rsort($daten);

var_dump($daten);
// sortieren
/*foreach() {
    if
}*/
$daten = [ 
    'jens','anton', 'Tim','Anke',
];

sort($daten,SORT_STRING | SORT_NATURAL) ; // ascending aufsteigend

//var_dump($daten);

$daten = ["img12.png", "img10.png", "img2.png", "img1.png"];

sort($daten,SORT_STRING) ; // ascending aufsteigend
var_dump($daten);