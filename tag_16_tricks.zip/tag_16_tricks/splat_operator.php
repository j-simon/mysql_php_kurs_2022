<?php

//$zeitpunkt = [23, 59, 0, 12, 31, 2008];

//[$stunde, $minute, $sekunde, $monat, $tag, $jahr] = $zeitpunkt;

$zeitpunkt = [23, 59, 0, 12, 31, 2008];
[$stunde, $minute, $sekunde, $monat, $tag, $jahr] = $zeitpunkt;

/*$stunde = 12;
$minute = 22;
$sekunde =42;
$monat = 11;
$tag=7;
$jahr=2022;*/

//$timestamp = mktime($stunde, $minute, $sekunde, $monat, $tag, $jahr);
$timestamp = mktime(...$zeitpunkt);

//echo $timestamp;

[,,$nachname]=['1','Jens','Simon'];
//echo $nachname;

function tueEtwas(int $par1,int $par2,int $par3){
 echo $par1,$par2,$par3;
}
$paras = [1,2,3];
//tueEtwas(1,2,3);
tueEtwas(...$paras);

