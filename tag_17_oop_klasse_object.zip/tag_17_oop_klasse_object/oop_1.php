<?php

// Variable
$vorname = "Jens";

// Funktionen
function gibNameAus($n) {
    // lokal
    echo $n;
}

gibNameAus("Katze");
gibNameAus($vorname);