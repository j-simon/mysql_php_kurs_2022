<?php

// Girokonto
// - Inhaber
// - Kontonummer
// - Guthaben

/* indizierte Array - numerisch */
$jensKonto = [];
$jensKonto[0]= "Jens Simon;";
$jensKonto[1]= "6353449904";
$jensKonto[2]= 0;

$timKonto = [];
$timKonto[0]= "6353449455";
$timKonto[1]= "Tim Schmitz";
$timKonto[2]= 10.5;

var_dump($jensKonto);

var_dump($timKonto);

// assoziatives Array
$jensKonto = [];
$jensKonto['inhaber']= "Jens Simon";
$jensKonto['kontonummer']= "6353449904";
$jensKonto['guthaben']= 100;

$timKonto = [];
$timKonto['kontonummer']= "6353449455";
$timKonto['inhaber']= "Tim Schmitz";
$timKonto['guthaben']= 10.5;

// Plus-Konto
// Bei jeder Einzahlung bekomme ich einen Bonus (0,50€)

var_dump($jensKonto);

var_dump($timKonto);

function gibKontoInhaberAus($konto){
    echo $konto['inhaber'];
}

// Inhaber1
gibKontoInhaberAus($jensKonto);

// Inhaber2
gibKontoInhaberAus($timKonto);

// Konto vom Jens soll 10€ bekommen
$jensKonto['guthaben'] += 10;
// Konto vom Jens soll 10€ bezahlen
$jensKonto['guthaben'] -= 10;
var_dump($jensKonto);

$timKonto['guthaben'] -= 10; // falsch kopiert Tim soll Geld bekommen

function zahleGeldEin($konto,$betrag){
    $konto['guthaben'] += $betrag;
    return $konto['guthaben'];
}

function zahleGeldAus($konto,$betrag){
    $konto['guthaben'] -= $betrag;
    return $konto['guthaben'];
}


$jensKonto['guthaben'] = 110;

$jensKonto['guthaben'] = zahleGeldEin($jensKonto,10);
var_dump($jensKonto);

function zahleGeldEinPlusKonto($konto,$betrag){
    $konto['guthaben'] += $betrag + 0.5;
    return $konto['guthaben'];
}