<?php

// Klassendefinition
class BonusKonto  {

    public $inhaber;
    public $kontonummer;
    public $guthaben;

    public function zahleGeldEin($betrag){
        
        $this->guthaben += $betrag + 0.5;
    }

}