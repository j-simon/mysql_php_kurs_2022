<?php


function gibKontoInhaberAus($konto){
    echo $konto['inhaber'];
}

function zahleGeldEin($konto,$betrag){
    $konto['guthaben'] += $betrag;
    return $konto['guthaben'];
}

function zahleGeldAus($konto,$betrag){
    $konto['guthaben'] -= $betrag;
    return $konto['guthaben'];
}

function zahleGeldEinPlusKonto($konto,$betrag){
    $konto['guthaben'] += $betrag + 0.5;
    return $konto['guthaben'];
}
