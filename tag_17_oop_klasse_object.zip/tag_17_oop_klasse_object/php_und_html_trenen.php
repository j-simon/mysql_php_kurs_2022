<?php
    $begruessung="Hallo";

    $inhalte=['1. Eintrag','2. Eintrag','3. Eintrag','4. Eintrag','5. Eintrag']
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>

    </head>
    <body>
        <p><?= $begruessung ?></p>
 
        <ul>
        <?php foreach($inhalte as $inhalt) { ?>
            <?php if ($inhalt=="3. Eintrag") { ?>
                <li><?= $inhalt ?></li>
            <?php } ?>
        <?php } ?>
        </ul>

        <ul>
        <?php 
        foreach($inhalte as $inhalt) { 
            if ($inhalt=="3. Eintrag") { 
                echo "<li>".$inhalt."</li>";
             } 
         } 
         ?>
        </ul>
    </body>
</html>