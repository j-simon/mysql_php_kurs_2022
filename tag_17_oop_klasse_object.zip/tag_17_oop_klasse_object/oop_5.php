<?php

require_once "Konto.php";
require_once "BonusKonto.php";

$jensKonto = new Konto();

$jensKonto->inhaber = "Jens Simon";
$jensKonto->ktonummer = "234342345";
$jensKonto->guthaben = 100;

$jensKonto->zahleGeldEin(10);

var_dump($jensKonto);


$timKonto = new BonusKonto();

$timKonto->inhaber = "Tim Schmitz";
$timKonto->kontonummer = "235654445";
$timKonto->guthaben = 1000;

$timKonto->zahleGeldEin(200);

var_dump($timKonto);

