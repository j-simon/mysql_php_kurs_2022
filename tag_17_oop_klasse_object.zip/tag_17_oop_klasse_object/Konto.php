<?php

// Klassendefinition
class Konto  {

    public $inhaber;
    public $ktonummer;
    public $guthaben;

    public function zahleGeldEin($betrag){
        
        $this->guthaben += $betrag;
    }

}