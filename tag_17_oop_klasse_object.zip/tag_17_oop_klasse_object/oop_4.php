<?php

// Objekt als PHP_Datentyp
// Datentypen
// - float , int , string, boolean , 

// int
$zahl = 12;
var_dump($zahl);

// array
$array = [1];
var_dump($array);

// object class
$test = new stdClass();


var_dump($test);