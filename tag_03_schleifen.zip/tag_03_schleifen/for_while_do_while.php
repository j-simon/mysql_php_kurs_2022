<?php
$anzahl=5;

for ($i=0 ; $i < $anzahl ; $i++)
    echo $i."<br>";
?>
<br>
<?php
$i = 0;
while ( $i < $anzahl){
    echo $i."<br>";
    $i++;
}
?>
<br>
<?php
$i = 0;
do {
    echo $i."<br>";
    $i++;
} while ($i < $anzahl);
?>



