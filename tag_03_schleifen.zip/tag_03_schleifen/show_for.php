<?php

// show.php?cars%5B%5D=volvo&cars%5B%5D=opel
// show.php?cars[]=volvo&cars[]=opel
$cars = $_GET['cars'] ?? [];
print_r($cars);
/*
Array ( 
    [0] => volvo
    [1] => saab 
    [2] => opel
    [3] => audi ) 


*/
?>
<h1> Autos</h1>
<ul>
    <?php for ($i = 0; $i<count($cars) ; $i++) { ?>
        <li><?php echo $cars[$i]; ?></li>
    <?php } ?>
</ul>
<ul>
    <?php for ($i = count($cars) -1; $i>=0 ; $i--) { ?>
        <li><?php echo $cars[$i]; ?></li>
    <?php } ?>
</ul>
<table>
    <?php foreach ($cars as $car) { ?>
        <tr>
            <td><?php echo $car; ?></td>
        </tr>
    <?php } ?>
</table>
<ul>
    <li>saab</li>
    <li>audi</li>
    <li>ferrari</li>
</ul>
<table>
    <tr>
        <td>saab</td>
    </tr>
    <tr>
        <td>audi</td>
    </tr>
    <tr>
        <td>ferrari</td>
    </tr>
</table>