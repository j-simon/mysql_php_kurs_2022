<?php


// assoziative Array-Element

/*echo "<br>GET<br>";
var_dump($_GET);

echo "<br>POST<br>";
var_dump($_POST);

echo "<br>REQUEST<br>";
var_dump($_REQUEST);

echo "<br>COOKIE<br>";
var_dump($_COOKIE);
*/

/* Name der Funktion */
/* lower CamelCase */
/* TeilWörter: 1.Wort wird kleingeschrieben */
/* TeilWörter: 1.Wort ein Verb im Imperativ */
/* TeilWörter: ab 2.Wort Substantive /Verb */

// 2. Aufruf/call
gibTextAusVonLinkDruecken();
gibTextAusVonLinkDruecken();

// 1. Deklaration
// Kopf
function gibTextAusVonLinkDruecken() {
    // Körper, was wird an Befehlen ausgeführt
    echo "<br>in funktion,";
    echo "hallo, ein Befehl, du hast den link gedrückt";
}



echo "<br>hallo, ein Befehl, du hast den link gedrückt";