<?php

// assoziative Array-Element

echo "<br>GET<br>";
var_dump($_GET);

echo "<br>POST<br>";
var_dump($_POST);

echo "<br>REQUEST<br>";
var_dump($_REQUEST);

echo "<br>COOKIE<br>";
var_dump($_COOKIE);