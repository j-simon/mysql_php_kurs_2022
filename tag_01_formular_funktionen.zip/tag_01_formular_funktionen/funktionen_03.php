<?php
// auslagern von Funktions-Deklaration(en)
require_once "funktionen.php";


function init(){
    myfunc1();
   
}




init(); // start : hier!

