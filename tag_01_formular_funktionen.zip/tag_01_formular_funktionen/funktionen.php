<?php

// Funktions-Deklarationen
function myfunc1(){
  echo "<br>myfunc1";
  myfunc3();
}

function myfunc2(){
   echo "<br>myfunc2";
   //init();
}

function myfunc3(){
    echo "<br>myfunc3";
    myfunc2();
}
