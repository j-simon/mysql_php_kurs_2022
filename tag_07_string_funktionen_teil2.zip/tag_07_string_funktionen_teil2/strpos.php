<?php
/*
str String
pos Position
*/
/* Nadel im Heuhaufen suchen */

$erste_fundstelle = strpos("Simon Jens, Koch Jens","Jens");
echo $erste_fundstelle; // 6
// Fundstelle ab 0 gezählt wird ermittelt
echo"<br>";

$zweite_fundstelle = strpos("Simon Jens, Koch Jens","Jens",$erste_fundstelle+1);
echo $zweite_fundstelle; // 17

echo"<br>";

$dritte_fundstelle = strpos("Simon Jens, Koch Jens  Jens","Jens",$zweite_fundstelle+1);
echo $dritte_fundstelle; // false
if($dritte_fundstelle==false)
 echo "false";