<?php

if ($_GET) {

    $textfeld = $_GET['textfeld'];
    var_dump($textfeld);
echo "<br>Der Zeilenumbruch wurde mit br-Tags erzielt!<br>";

    $geaenderterText = nl2br($textfeld);
    echo $geaenderterText;
}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title></title>
    
</head>

<body>
    <form action="">
        <textarea name="textfeld">Jens
Simon
        </textarea>
        <input type="submit">
    </form>
</body>

</html>