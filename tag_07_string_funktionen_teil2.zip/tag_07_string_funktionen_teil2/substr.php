<?php

/*
sub: Teil
str: String
*/

$text="Hier passiert gleich folgendes: Mittagspause";

$erste_fundstelle = strpos($text,":");
echo $erste_fundstelle; // 14
echo"<br>";
$teilstring = substr($text,$erste_fundstelle+1);
echo $teilstring;
echo"<br>";
echo $text;

echo"<br>";
$text="Tim  Schmitzewitz";

$erste_fundstelle = strpos($text," ");
echo $erste_fundstelle; //variable
echo"<br>";
$teilstring = substr($text,$erste_fundstelle+1);
echo trim($teilstring);
echo"<br>";
//echo $text;