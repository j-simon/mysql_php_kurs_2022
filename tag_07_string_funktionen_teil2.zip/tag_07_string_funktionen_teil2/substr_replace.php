<?php
/*
substr_replace(
    array|string $string,
    array|string $replace,
    array|int $offset,
    array|int|null $length = null
): string|array*/

/* str_replace()
String 
Ersetzung
*/

echo "<br>";

$replace = ", Simon";

$vorname = "Jens   Simon";

echo substr_replace($vorname, $replace, 4);
echo "<br>";

