<?php
/* 
explode()
implode()

strip_tags()
nl2br()
*/
/*
$name ="Jens Simon Tim Schmitz";

$namensteile = explode(" ",$name,2);
echo"<pre>";
var_dump($namensteile);
echo"</pre>";

echo "<br>";
$text=implode(" ",$namensteile);
echo $text;
echo "<br>";*/
/*
strip_tags()
nl2br()
*/
$htmlText="<section><p style='color:red'><b>Jens Simon</b></p><section>";

var_dump(strip_tags($htmlText,["<p>","<b>"]));

