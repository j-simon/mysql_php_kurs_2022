<?php
// count
$arr=[1,3,6];
echo count($arr);
echo "<br>";
//strlen String Länge (length)
// KarlWalter
$_GET['vorname'];
$vorname=$_GET['vorname'];

echo strlen($vorname);
echo "<br>";
echo strlen($arr);