<?php

/* str_replace()
String 
Ersetzung
*/
$search = "e";
$replace = "ä";

$vorname = "Jens";

echo str_replace($search, $replace, $vorname);

echo "<br>";
$search = " ";
$replace = ",";

$vorname = "Jens   Simon";

$count=0;
echo str_replace($search, $replace, $vorname,$count);
echo "<br>";
echo $count;
