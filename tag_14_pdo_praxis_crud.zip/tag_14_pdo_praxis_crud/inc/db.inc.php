<?php
 // Datenbank-Client selbst programmiert


 // MAMP
 $hostname = "localhost";// "mysql31.1blu.de" // ip-adresse oder über einen domain-name
 $port = 3308; // 3306
 $dbname = "unicode_test_4_aus_php_erzeugt";
 $username = "root";
 $password = "root"; 

 // XAMPP
 /*
 $hostname = "localhost";
 $dbname = "mysql";
 $username = "root";
 $password = "";*/

$dsn = 'mysql:host='.$hostname.';port='.$port.';dbname='.$dbname; // data source name // datenquellen name -> welchen servertyp und adresse
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_BOTH
];
 
// Der Erzeugung eines PDO Objektes
// 1.Verbindungsaufbau mit Server
$db = new PDO($dsn,$username, $password,$options ) ; // Klasse dient der Einstellung der Server
$db->query('SET NAMES utf8');

