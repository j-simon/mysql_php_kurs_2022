<?php
require_once "inc/db.inc.php";

$id =   $_GET['id'];

//echo $id;

// D-Konzept
$db->query("DELETE FROM genres WHERE id=" . $id . ";   ");

header('Location: index.php');
exit();