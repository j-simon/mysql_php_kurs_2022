<?php


require_once "inc/db.inc.php";

if (!$_POST) {
    // Startmoment
    $id =   $_GET['id'];
    echo $id;

    // R
    // R-Konzept
    // 2. SQL-Befehl formulieren und zum Server schicken
    $ergebnis = $db->query("SELECT * FROM genres WHERE id=$id;");
    //var_dump($ergebnis);


    // 3. Ergebnis vom Server abholen // 2dim Array
    $daten = $ergebnis->fetch();
    //var_dump($daten);
    $titel = $daten['titel'] ?? '';
    $bemerkung = $daten['bemerkung'] ?? '';
   
} else {
    // Speichern
    $titel_neu = $_POST['titel'];
    $bemerkung_neu = $_POST['bemerkung'];
    
    $id=$_POST['id'];
    // U-Konzept
    $ergebnis = $db->query("    UPDATE genres SET titel='$titel_neu' ,  bemerkung='$bemerkung_neu'   WHERE id=$id;   ");

    header('Location: index.php');
    exit();
}

?>
<?php

?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>U - Konzept</title>
</head>

<body>
    <form action="<?= $_SERVER['PHP_SELF'] ?>" method="POST">
        <input type="hidden" name="id" value="<?= $id?>">
        <input type="text" value="<?= $titel ?>" name="titel"><br>
        <input type="text" value="<?= $bemerkung ?>" name="bemerkung">
        <input type="submit" value="aendern">

    </form>
</body>

</html>

<?php
