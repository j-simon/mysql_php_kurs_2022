<?php
require_once "inc/db.inc.php";

$titel =   $_POST['titel'];
$bemerkung =   $_POST['bemerkung'];

//echo $titel;


// C - Konzept
// ohne Schutz
/*$sqlBefehl = "INSERT INTO genres (titel,bemerkung) VALUES('$titel','$bemerkung');";
$ergebnis = $db->query($sqlBefehl);
*/


// mit SQLi ( SQL Injection) Schutz
// Variante a) mit nummerischen Array
/*$sqlBefehl = "INSERT INTO genres (titel,bemerkung) VALUES(?,?);";
$ergebnis = $db->prepare($sqlBefehl);

$ergebnis->execute([$titel]);*/

// Variante b) mit assoziativen Array
$sqlBefehl = "INSERT INTO genres (titel,bemerkung) VALUES(:titel , :bemerkung);";
$ergebnis = $db->prepare($sqlBefehl);

$ergebnis->execute([
                    'titel' => $titel,
                    'bemerkung' => $bemerkung,
]);

header('Location: index.php');
exit();

// ');DELETE FROM genres;

     PDO
C    INSERT 
R    SELECT
U    UPDATE
D    DELETE