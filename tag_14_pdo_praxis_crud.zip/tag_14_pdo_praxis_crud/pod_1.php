<?php
 // Datenbank-Client selbst programmiert


 // MAMP
 $hostname = "localhost";// "mysql31.1blu.de" // ip-adresse oder über einen domain-name
 $port = 3308; // 3306
 $dbname = "filme";
 $username = "root";
 $password = "root"; 

 // XAMPP
 /*
 $hostname = "localhost";
 $dbname = "mysql";
 $username = "root";
 $password = "";*/

$dsn = 'mysql:host='.$hostname.';port='.$port.';dbname='.$dbname; // data source name // datenquellen name -> welchen servertyp und adresse
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_BOTH
];
 
// Der Erzeugung eines PDO Objektes
// 1.Verbindungsaufbau mit Server
$db = new PDO($dsn,$username, $password,$options ) ; // Klasse dient der Einstellung der Server
$db->query('SET NAMES utf8');

// 2. SQL-Befehl formulieren und zum Server schicken
$dbName="unicode_test_4_aus_php_erzeugt";

$ergebnis = $db->query("DROP DATABASE IF EXISTS ".$dbName.";");

$ergebnis = $db->query("CREATE DATABASE ".$dbName.";");

$ergebnis = $db->query("USE ".$dbName.";");

$db->query("CREATE TABLE genres 
            (
              id INTEGER PRIMARY KEY AUTO_INCREMENT,
              titel VARCHAR(100) 
            );
        ");
        
/*// Variante mit nur einem Query, in dem alle SQL Befehle ; getrennt ausgeführt
$ergebnis = $db->query("DROP DATABASE IF EXISTS ".$dbName.";CREATE DATABASE ".$dbName.";USE ".$dbName.";CREATE TABLE genres 
(
  id INTEGER PRIMARY KEY AUTO_INCREMENT,
  titel VARCHAR(100) 
);");
*/
// C - Konzept
$ergebnis = $db->query("INSERT INTO genres 
                        (id,titel)
                        VALUES(1,'SciFi');");

$ergebnis = $db->query("INSERT INTO genres 
                        (titel)
                        VALUES('Horror');");

// CRUD - Konzept SQL   
// C: INSERT INTO
// R: SELECT  
// U: UPDATE
// D: DELETE FROM

// CRUD - Konzept PHP
// C: $a=10;   
// R: echo $a; oder $b = $a;
// U: $a=20; 
// D: unset($a)



// U-Konzept
$ergebnis = $db->query("    UPDATE genres SET titel='HorrorFilm' WHERE id=2;   ");
                        
                        



// D-Konzept
//$ergebnis = $db->query("    DELETE FROM genres WHERE id=2;   ");

// R-Konzept
// 2. SQL-Befehl formulieren und zum Server schicken
$ergebnis = $db->query("SELECT * FROM genres;");
//var_dump($ergebnis);


// 3. Ergebnis vom Server abholen // 2dim Array
$daten = $ergebnis->fetchAll();
//var_dump($daten);

// 4. Verarbeitung
foreach($daten as $zeile) {
    echo $zeile['id']." ".$zeile['titel']."<br>";
}