<?php
 require_once "inc/db.inc.php";


    // R-Konzept
    // 2. SQL-Befehl formulieren und zum Server schicken
    //$ergebnis = $db->query("SELECT * FROM genres;");// LIMIT 1,2 ;");

     // Prepared Statement für LIMIT !
     $pre = $db->prepare("SELECT * FROM genres ORDER BY titel ");
     // geht nicht $returncode= $pre->execute(['anfang' => 0, 'anzahl' => 100]);
     //$pre->bindValue(":anfang", 0, PDO::PARAM_INT);
     //$pre->bindValue(":anzahl", 100, PDO::PARAM_INT);
     $returncode= $pre->execute();

    //var_dump($ergebnis);


    // 3. Ergebnis vom Server abholen // 2dim Array
    $daten = $pre->fetchAll();
   var_dump($daten);

   usort($daten,function($a,$b){
        return  strtolower($b['titel']) <=> strtolower($a['titel']);
   });


?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        

    <p>Einträge<p>
    
    <ul>
    <?php foreach($daten as $zeile) { ?>
     <li><a href="loeschen.php?id=<?= $zeile['id']?>"><img style="width:10px;" src="assets/img/delete-icon-13.png"></a>
     <a href="aendern.php?id=<?= $zeile['id']?>"><img style="width:10px;" src="assets/img/updateicon-13.png"></a>
     <?= $zeile['id']?> - <?= $zeile['titel']  ?> - <?= $zeile['bemerkung']?> </li>  
    <?php } ?>
    </ul>
    <br />

    <form action="speichern_neu.php" method="POST">
         <input type="text" placeholder="Genre Titel" name="titel"><br>
         <input type="text" placeholder="Genre Bemerkung" name="bemerkung">
         <input type="submit" value="speichern">

       </form>
</body>
</html>