<pre>
<?php

var_dump($_POST);

$inhalt = htmlspecialchars($_POST['inhalt']);
$inhalt  = str_replace("'","&lsquo;",$inhalt);
echo $inhalt;
 // Datenbank-Client selbst programmiert


 // MAMP
 $hostname = "localhost";// "mysql31.1blu.de" // ip-adresse oder über einen domain-name
 $port = 3308; // 3306
 $dbname = "wysiwyg";
 $username = "root";
 $password = "root"; 

 // XAMPP
 /*
 $hostname = "localhost";
 $dbname = "mysql";
 $username = "root";
 $password = "";*/

$dsn = 'mysql:host='.$hostname.';port='.$port.';dbname='.$dbname; // data source name // datenquellen name -> welchen servertyp und adresse
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_BOTH
];
 
// Der Erzeugung eines PDO Objektes
// 1.Verbindungsaufbau mit Server
$db = new PDO($dsn,$username, $password,$options ) ; // Klasse dient der Einstellung der Server
$db->query("SET NAMES utf8");

// 2. INSERT Befehl
$db->query("INSERT INTO beispiel (content) VALUES('".$inhalt."')");

?>
</pre>