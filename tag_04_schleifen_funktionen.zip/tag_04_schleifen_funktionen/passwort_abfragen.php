<?php

$accounts = [];

$accounts[0]['username'] = "jens.simon@gmx.net";
$accounts[0]['password'] = "_geheim_:";

$accounts[1]['username'] = "jens.simon@gfn.de";
$accounts[1]['password'] = "_123geheim_:";

$accounts[2]['username'] = "kim.schmitz@aol.com";
$accounts[2]['password'] = "ABC:";

echo $_GET['username'];
echo $_GET['password'];

$loggedin = false;

foreach ($accounts as $account) {

    if ($_GET['username'] == $account['username'] &&      $_GET['password'] == $account['password']) {

        $loggedin = true;
        break;
    }
}

if ($loggedin == true) {
    echo "<br>hier beginnt der Account Bereich";
} else
    echo "<br>bitte nochmal versuchen";
