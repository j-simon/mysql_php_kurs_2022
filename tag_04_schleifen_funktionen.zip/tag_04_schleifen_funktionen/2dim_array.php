<?php

$daten = [];

$daten[0]=4;
$daten[1]=55;
$daten[2]=884;
var_dump($daten);
foreach($daten as $data){
    echo $data; // einzelwert
}

echo "<br><br>";
$daten = [];
$daten[0][0]=4;  $daten[0][1]=7; $daten[0][2]=90;
$daten[1][0]=6;  $daten[1][1]=-7; $daten[1][2]=9;
$daten[2][0]=9;  $daten[2][1]=337; $daten[2][2]=1;
var_dump($daten);

echo "<br>";

$daten = [
    [4,7,90],
    [6,-7,9],
    [9,337,1]
];

var_dump($daten);
echo "<br>";

foreach($daten as $data){
    foreach($data as $einzelwert){
        echo " " . $einzelwert; //einzelwert
    }
    echo "<br>";
}
echo "<br>";
$daten=[];
$daten[0]['vorname']="Jens";
$daten[0]['nachname']="Simon";
$daten[0]['email']="jens.simon@gmx.net";

$daten[1]['vorname']="Uwe";
$daten[1]['nachname']="Steinberg";
$daten[1]['email']="uwe.steinberg@braunsfeld.com";
foreach($daten as $data){
    foreach($data as $einzelwert){
        echo " " . $einzelwert; //einzelwert
    }
    echo "<br>";
}