<?php
$eineVariable; // globale Variable

//echo $_GET['vorname'];
//echo $_GET['nachname'];

// Parameter
function showMyName($vorname,$nachname="nicht bekannt"){
    //$vorname="Jens";
     // lokale Variable
    
     $returnValue = "Mein Name ist ".$vorname." ".$nachname;
     
     
     return $returnValue; // nur eine Variable kann wieder raus 
}
$aufgefangeneVariable = showMyName($_GET['vorname'] ); // Parameter wird hier initialisiert
echo $aufgefangeneVariable;
echo "<br>";
$aufgefangeneVariable = showMyName($_GET['vorname'] , $_GET['nachname']); // Parameter wird hier initialisiert
echo $aufgefangeneVariable;


echo "<br>Beispiel Summe berechnen<br>";

function berechneSumme($a,$b){
    // lokale Variable
    $returnValue = $a + $b;
    return $returnValue;
}
$ergebnis1 = berechneSumme(2,6);
echo $ergebnis1;
echo "<br>";
$ergebnis1 = berechneSumme(12,56);
echo $ergebnis1;
echo "<br>";
$ergebnis1 = berechneSumme(42,46);
echo $ergebnis1;
echo "<br>";
$ergebnis1 = berechneSumme(23,6);
echo $ergebnis1;
