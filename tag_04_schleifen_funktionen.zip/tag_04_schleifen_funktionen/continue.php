<?php


for ($i = 1; $i <= 10; $i++) {


    /*if ($i == 3 ||
          $i == 4 || 
          $i == 6 || 
          $i == 7 || 
          $i == 9)
        continue; // beende an dieser Stelle den Schleifenkörper
   */
    switch ($i) {
        case 3:
        case 4:
        case 6:
        case 7:
        case 9:
            continue 2;
    }
    echo "<br>" . $i;
}
