<?php


for ($i = 1; $i <= 10; $i++) {

    echo "<br>" . $i;
    if ($i == 6 )
        break; // beende an dieser Stelle die Kontrollstruktur
   
   
  
}
echo "<br>hier gehts es weiter";
