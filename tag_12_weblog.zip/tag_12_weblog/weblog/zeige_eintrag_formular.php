<?php
require "inc/konfiguration.inc.php";
require "inc/funktionen.inc.php";

session_start();

if(!istEingeloggt()){
    header('Location: index.php');
    exit();
}

//$eintraege = holeEintraege(true); // true : umgedrehte reihenfolge
//$eintraege = holeEintraege(false); // false : original reihenfolge
//var_dump($eintraege);

?>
        <?php 
            $titel="Eintrag hinzufügen";
            include "inc/header.tpl.php"; 
        ?>


        <section id="content">
            <h1>Schreiben Sie hier einen neuen Eintrag:</h1>

            <form action="speichere_eintrag.php" method="post">
                <input type="text" name="titel" id="titel" required="required" placeholder="Titel" />
                <textarea name="inhalt" id="inhalt" cols="50" rows="10" required="required" placeholder="Inhalt"></textarea>
                <input type="submit" value="Eintragen" />
            </form>

        </section>

        <?php include "inc/footer.tpl.php"; ?>