<?php
require "inc/konfiguration.inc.php";
require "inc/funktionen.inc.php";

session_start();

if(!istEingeloggt()){
    header('Location: index.php');
    exit();
}

//$eintraege = holeEintraege(true); // true : umgedrehte reihenfolge
//$eintraege = holeEintraege(false); // false : original reihenfolge
//var_dump($eintraege);
$eintraege = holeEintraege(false); // false : original reihenfolge
$eintrag=[];

foreach ($eintraege as $i => $eintrag) {


    if ($eintrag['key'] == $_GET['key'] && 
        $_SESSION['eingeloggt'] == $eintrag['autor']) {
    
        //echo "gefunden";
        $eintrag=$eintraege[$i];
        break;
    }

}



$e_titel=trim($eintrag['titel']);
$e_inhalt=trim($eintrag['inhalt']);
?>
        <?php 
            $titel="Eintrag ändern";
            include "inc/header.tpl.php"; 
        ?>


        <section id="content">
            <h1>Ändern Sie hier Ihren Eintrag:</h1>

            <form action="aendere_eintrag.php" method="post">
                <input type="hidden" name="key" value="<?= $_GET['key'] ?>">
                <input type="text" name="titel" id="titel" required="required" value="<?= $e_titel ?>" />
                <textarea name="inhalt" id="inhalt" cols="50" rows="10" required="required"><?= $e_inhalt ?>
                </textarea>
                <input type="submit" value="Speichern" />
            </form>

        </section>

        <?php include "inc/footer.tpl.php"; ?>