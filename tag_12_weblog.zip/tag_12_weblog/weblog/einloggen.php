<?php
require "inc/konfiguration.inc.php";
require "inc/funktionen.inc.php";
session_start();

// BENUTZER_DATEN[][]
$key_user =$_POST['benutzername']; // ghegel

if ( !empty(BENUTZER_DATEN[$key_user]) &&
     BENUTZER_DATEN[$key_user]['passwort'] ==
    $_POST['passwort'] 
) {
    loggeEin($key_user);
   
} else {
    $_SESSION['meldung']="Falsche Login-Daten, bitte versuchen Sie es nochmal!";
}
 // header
 header('Location: index.php');
 exit();
