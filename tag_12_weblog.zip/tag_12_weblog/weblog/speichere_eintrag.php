<?php

require "inc/konfiguration.inc.php";
require "inc/funktionen.inc.php";

session_start();

if(!istEingeloggt()){
    header('Location: index.php');
    exit();
}


$eintraege = holeEintraege();


$eintraege[]= 
[
        'titel' => trim(htmlspecialchars($_POST['titel'])),
        'inhalt' => trim(htmlspecialchars(nl2br($_POST['inhalt']))),
        'erstellt_am' => time() ,
        'autor' => holeEingeloggterBenutzer(),
        'key' =>  md5(trim(htmlspecialchars($_POST['titel']))),
    ];

file_put_contents(PFAD_EINTRAEGE, serialize($eintraege));

header("Location: index.php");// - befehl noch einfuegen
exit();
 // hier vergisst php alles was vorher war!


