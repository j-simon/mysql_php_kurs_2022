<?php

require "inc/konfiguration.inc.php";
require "inc/funktionen.inc.php";

session_start();

if(!istEingeloggt()){
    header('Location: index.php');
    exit();
}

$eintraege = holeEintraege();


echo $_GET['key'];



foreach ($eintraege as $i => $eintrag) {

    if ($eintrag['key'] == $_GET['key'] && 
        $_SESSION['eingeloggt'] == $eintrag['autor']) {
    
        echo "gefunden";
        unset($eintraege[$i]);
        break;
    }


}

//var_dump($eintraege);

// loesche
// suchen das element mit dem unterkey 'key'



// shift

file_put_contents(PFAD_EINTRAEGE, serialize($eintraege));


//var_dump($eintraege);

header("Location: index.php");// - befehl noch einfuegen
exit();

// hier vergisst php alles was vorher war!
///////////////////////////////////////////
// hinzufügen

// 1. lade aktuellen Stand z.b 4 Elemente

// 2. hinzufügen 5. Element , []

// 3. alles speichern

////////////////////////////////////////////
// loeschen

// 1. lade aktuellen Stand z.b 4 Elemente

// 2. loeschen ?. Element , [0],[1],   ['key'}

// 3. alles speichern