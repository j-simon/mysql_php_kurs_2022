<?php
require "inc/konfiguration.inc.php";
require "inc/funktionen.inc.php";

session_start();

//$eintraege = holeEintraege(true); // true : umgedrehte reihenfolge
$eintraege = holeEintraege(false); // false : original reihenfolge
//var_dump($eintraege);

?>

        <?php 
            $titel="Startseite - Weblog";
            include "inc/header.tpl.php"; 
        ?>

        <section id="content">
            <?php foreach ($eintraege as $e) : ?>
                <?php include "inc/eintrag.tpl.php";    ?>
            <?php endforeach ?>
        </section>

        <?php include "inc/footer.tpl.php"; ?>