<?php
require "inc/konfiguration.inc.php";
require "inc/funktionen.inc.php";
session_start();



loggeAus();

header('Location: index.php');
exit();