<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title><?= $titel ?></title>
    <link href="css/stylesheet.css" rel="stylesheet">
</head>

<body>

    <div id="gesamt">

        <header id="kopf">
            <h1>Mein Weblog</h1>
        </header>