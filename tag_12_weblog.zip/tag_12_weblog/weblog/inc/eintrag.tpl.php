<article class="eintrag">
    <header class="eintrag_oben">
        <h1><?= $e['titel'] ?></h1>
    </header>

    <p>
        <?= $e['inhalt'] ?>
    </p>

    <footer class="eintrag_unten">
        <span>
            <?php
            //echo "eingeloggert user: ".$_SESSION['eingeloggt'];
            //var_dump($e);

            if (
                istEingeloggt() &&
                $_SESSION['eingeloggt'] == $e['autor']
            ) {  ?>
                <a href="aendere_eintrag_formular.php?key=<?= $e['key']?>">ändern</a>
                <a href="loesche_eintrag.php?key=<?= $e['key']?>">löschen</a>
            <?php } ?>


            geschrieben von
            <?= BENUTZER_DATEN[$e['autor']]['vorname'] ?>
            <?= BENUTZER_DATEN[$e['autor']]['nachname'] ?>
            am
            <time datetime="<?= strftime('%Y-%m-%dT%H:%M:%S', $e['erstellt_am']) ?>">
                <?= strftime('%d.%m.%Y um %H:%M', $e['erstellt_am']) ?>
            </time>
        </span>
    </footer>
</article>