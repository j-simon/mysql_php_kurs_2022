<?php
$meldung="";
if (isset($_SESSION['meldung']))
    $meldung = $_SESSION['meldung'];

?>
<h3 style="color:red"><?= $meldung ?></h3>
<form action="einloggen.php" method="post">
    <input type="text" name="benutzername" id="benutzername" required="required" placeholder="Benutzername" />
    <input type="password" name="passwort" id="passwort" required="required" placeholder="Passwort" />
    <input type="submit" value="Einloggen" class="button" />
</form>