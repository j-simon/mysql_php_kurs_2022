<div class="aside" id="menu">
            <?php 
            if(istEingeloggt()) {  
                include "inc/hauptmenu.tpl.php";  
            } else {
                include "inc/loginformular.tpl.php";  
            }
            ?>
        </div>
        <footer id="fuss">
           Das ist das Ende
        </footer>
    </div>
</body>

</html>