<?php

 // login / einlogen
 // session_start();
 // $_SESSION

 function istEingeloggt(){ 
    return  isset($_SESSION['eingeloggt']);
 }

 function loggeEin($username) {
    $_SESSION['eingeloggt'] = $username;
 }

 function loggeAus() {
    //unset($_SESSION['eingeloggt']);
    session_destroy();
 }

 function holeEingeloggterBenutzer(){
    return  $_SESSION['eingeloggt'];
 }

 // Funktionen Daten
// speichern

// lesen
function holeEintraege($umgedreht=false){
   if (file_exists(PFAD_EINTRAEGE)) {
      $eintraege = unserialize(file_get_contents(PFAD_EINTRAEGE));
      if ($umgedreht === true) {
          $eintraege = array_reverse($eintraege);
      }
  } else {
      $eintraege = [];
  }

  return $eintraege;
}
